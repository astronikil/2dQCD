*Smearing parameters
      parameter (eps=0.6, eps2=0.5, nlev=1)
      parameter (ep4=eps/4., epsq8=eps2*eps2/8.)

*Clover parameter
      real kcs
      parameter (kcs=0.0)
